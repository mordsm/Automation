#ifndef FONTFORGE_START_H
#define FONTFORGE_START_H

extern void doinitFontForgeMain(void);
extern void doversion(const char *source_version_str);
extern void InitSimpleStuff(void);

#endif /* FONTFORGE_START_H */
